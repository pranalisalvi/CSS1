package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.util.JndiUtil;

public class UniversityDaoImpl implements UniversityDao {
	private JndiUtil util = null;

	public UniversityDaoImpl() throws UniversityAdmissionException {
		try {
			util = new JndiUtil();
		} catch (UniversityAdmissionException e) {
			throw new UniversityAdmissionException("Error In JNDI Connection");
		}
	}

	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {

		// SHOWING DEATILS
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		List<Application> list = new ArrayList<Application>();

		String Query = "select * from Application where status ='applied' ";
		try {

			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();

			while (rs.next()) {
				int Application_id = rs.getInt("Application_id");
				String full_name = rs.getString("full_name");
				java.sql.Date date_of_birth = rs.getDate("date_of_birth");
				String highest_qualification = rs
						.getString("highest_qualification");
				int marks_obtained = rs.getInt("marks_obtained");

				String goals = rs.getString("goals");
				String email_id = rs.getString("email_id");
				String Scheduled_program_id = rs
						.getString("Scheduled_program_id");
				String status = rs.getString("status");
				java.sql.Date Date_Of_Interview = rs
						.getDate("Date_Of_Interview");

				Application application = new Application(Application_id,
						full_name, date_of_birth, highest_qualification,
						marks_obtained, goals, email_id, Scheduled_program_id,
						status, Date_Of_Interview);

				list.add(application);
			}

			return list;

		} catch (SQLException e) {
			throw new UniversityAdmissionException("UNABLE TO FETCH DATA"+e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					throw new UniversityAdmissionException(
							"Connection Closing failed");
				}
			}

		}

	}

	@Override
	public boolean addProgram(ProgramsOffered p)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		
		String Query = "insert into Programs_Offered values(?,?,?,?,?) ";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, p.getProgramName());
			stat.setString(2, p.getDescription());
			stat.setString(3, p.getApplicantEligility());
			stat.setInt(4, p.getDuration());
			stat.setString(5, p.getDegree_certificate_offered());
			rs = stat.executeQuery();
			if (rs.next()) {
			
				return true;

			} else {

				throw new UniversityAdmissionException(
						"UNABLE TO INSERT>> USER REGESTRATION FAILED");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;



		String Query = " DELETE FROM Programs_Offered WHERE ProgramName=? ";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, ProgramName);
			rs = stat.executeQuery();
			if (rs.next()) {
			
				return true;

			} else {

				throw new UniversityAdmissionException("CAN NOT DELETE DATA");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		String Query = "UPDATE Programs_Offered SET description = ?, applicant_eligibility=?,duration=?,degree_certificate_offered = ? WHERE ProgramName=? ";

		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, p.getDescription());
			stat.setString(2, p.getApplicantEligility());
			stat.setInt(3, p.getDuration());
			stat.setString(4, p.getDegree_certificate_offered());
			stat.setString(5, p.getProgramName());
			int r = stat.executeUpdate();
					if (r>=1) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			//throw new UniversityAdmissionException(	"CAN NOT UPADTE INTO Programs_Offered");
e1.printStackTrace();
		}
		return false;

	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		String Query = "UPDATE Application SET status = ?, Date_Of_Interview=? WHERE Application_id=? ";

		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, application.getStatus());
			stat.setDate(2, application.getDate_Of_Interview());
			stat.setInt(3, application.getApplication_id());
			rs = stat.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			throw new UniversityAdmissionException(
					"CAN NOT UPADTE INTO Application");

		}

	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {

		// SHOWING DEATILS
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		List<ProgramsOffered> list = new ArrayList<ProgramsOffered>();

		String Query = "select * from Programs_Offered ";
		try {

			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();

			while (rs.next()) {

				String degree_certificate_offered = rs
						.getString("degree_certificate_offered");
				int duration = rs.getInt("duration");
				String ProgramName = rs.getString("ProgramName");
				String applicantEligility = rs.getString("applicant_eligibility");
				String description = rs.getString("description");
				ProgramsOffered programsOffered = new ProgramsOffered(
						ProgramName, description, applicantEligility, duration,
						degree_certificate_offered);
				list.add(programsOffered);
			}

			return list;

		} catch (SQLException e) {
			//throw new UniversityAdmissionException("UNABLE TO FETCH DATA");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					throw new UniversityAdmissionException(
							"Connection Closing failed");
				}
			}

		}
		return list;

	}
	
	
	public Users getUserDetail(String userName)throws UniversityAdmissionException {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query ="SELECT password, role FROM Users WHERE login_id=?";
		
		
		try {
			conn= util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,userName);
			rs=pstm.executeQuery();
			System.out.println("Hiii1");
			if(rs.next()){
				String password=rs.getString("PASSWORD");
				String role=rs.getString("role");
				Users user=new Users(userName, password, role);
			
				System.out.println("Hiii1"+user);
				return user;
				
			}else{
			
			throw new UniversityAdmissionException(" Wrong UserName");
			}
			
			
		} catch (SQLException e) {
			
			   throw new UniversityAdmissionException("No jndi connection",e);
				
		}
		finally{}	
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled()throws UniversityAdmissionException{
	
		List<ProgramsScheduled> programList=new ArrayList<ProgramsScheduled>();
		Connection conn = null;
	
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query ="SELECT * FROM Programs_Scheduled";
		System.out.println("ps1");
		
		try {
		
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			rs=pstm.executeQuery();
					
			while(rs.next()){
				System.out.println(2);
				ProgramsScheduled program = new ProgramsScheduled();
				program.setScheduled_program_id(Integer.parseInt(rs.getString("Scheduled_program_id")) );
				program.setProgramName(rs.getString("ProgramName"));
				program.setLocationID(rs.getString("LocationID"));
				program.setStart_date(rs.getDate("start_date"));
				program.setEnd_date(rs.getDate("end_date"));
				program.setSessions_per_week(rs.getInt("sessions_per_week"));
				System.out.println(program);
				programList.add(program);	
				}
		
			
		} catch (SQLException e) {
			
			   throw new UniversityAdmissionException("Program Shedule Not Selected",e);
				
		}
		finally{
			
		}
		return programList;
		}

	@Override
	public List<Application> getApplicationOnSheduledId(String ScheduleId)
			throws UniversityAdmissionException {
	
		Connection conn = null;
		List<Application> applicantList=new ArrayList<Application>();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query ="SELECT * FROM Application where Scheduled_program_id=? and status=?";
		Application application = new Application();
		
		try {
			conn= util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1, ScheduleId);
			pstm.setString(2,"accepted");
			rs=pstm.executeQuery();
			
			while(rs.next()){
				
				application.setApplication_id(rs.getInt("Application_id"));
				application.setFull_name(rs.getString("full_name"));
				application.setDate_of_birth(rs.getDate("date_of_birth"));
				application.setHighest_qualification(rs.getString("highest_qualification"));
				application.setMarks_obtained(rs.getInt("marks_obtained"));
				application.setGoals(rs.getString("goals"));
				application.setEmail_id(rs.getString("email_id"));
				application.setScheduled_program_id(rs.getString("Scheduled_program_id"));
				application.setStatus(rs.getString("status"));
				application.setDate_Of_Interview(rs.getDate("Date_Of_Interview"));
				applicantList.add(application);
				}
			
		} catch (SQLException e) {
			
		//	   throw new UniversityAdmissionException("Applicant Data Not Selected",e);
			e.printStackTrace();
				
		}
		finally{}
		return applicantList;
	}


	@Override
	public boolean updateApplicationDB(int id,String status)
			throws UniversityAdmissionException {
		Connection conn = null;
		List<Application> applicantList=new ArrayList<Application>();
		PreparedStatement pstm = null;
		int rec;
		String query ="update Application set status=? where Application_id=?";
		
		
		try {
			conn= util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,status);
			pstm.setInt(2,id);
			rec=pstm.executeUpdate();
			
			if(rec>0){
				return true;
			}
			
		} catch (SQLException e) {
			
			   throw new UniversityAdmissionException("Applicant Data Not Updated",e);
				
		}
		finally{}
	
		return false;
	}
	
	@Override
	public List<Application> showApplicantInfo(String status,Date sqlStartDate,Date sqlEndDate)
			throws UniversityAdmissionException {
		System.out.println("IndaoImpl");
		
		Connection conn=null;
		PreparedStatement pstm=null;
		
		List<Application> applicantList = new ArrayList<Application>();
		
		String qry = "SELECT appl.Application_id,appl.full_name,appl.status,appl.Scheduled_program_id FROM Application appl JOIN Programs_Scheduled ps ON appl.Scheduled_program_id=ps.Scheduled_program_id WHERE((status=?)AND(start_date=? AND end_date=?))";
		try {				System.out.println("xxx");
			conn = util.getConnection();
			pstm=conn.prepareStatement(qry);
			pstm.setString(1,status);
			pstm.setDate(2, sqlStartDate);
			pstm.setDate(3, sqlEndDate);
			ResultSet rs = pstm.executeQuery();
			System.out.println("xxx");
			while(rs.next()){
				System.out.println("xxx");
				Application appl = new Application();
				appl.setApplication_id(rs.getInt("Application_id"));
				appl.setFull_name(rs.getString("full_name"));
				appl.setStatus(rs.getString("status"));
				appl.setScheduled_program_id(rs.getString("Scheduled_program_id"));
				System.out.println(appl);
				applicantList.add(appl);
				System.out.println(appl);
				
			}
			
		return applicantList;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityAdmissionException("Problem occured while showing applicant Details",e);
		}
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();	
		}
		}
		
		
	}



}
